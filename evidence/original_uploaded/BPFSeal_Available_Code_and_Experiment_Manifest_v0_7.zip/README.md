# BPFSeal experimental artifact — accessible files only

Date: 2026-11-03  |  Paper: BPFSeal empirical manuscript v0.7

## IMPORTANT COMPLETENESS WARNING

This ZIP is NOT the full BPFSeal patched Linux-kernel repository. The EC2 instance
was stopped before export. This ZIP contains actual C/Python/bash source files
previously supplied or generated in this conversation. The critical kernel changes
(`kernel/bpf/arraymap.c`, `kernel/bpf/syscall.c`, `include/linux/bpf.h`), full raw
per-operation CSVs, original B2 trace and perf.data files are NOT present here.
Do not claim full experimental reproducibility from this ZIP alone.

## Contents

- `code/performance/`: original available P1 C benchmark and runner scripts.
- `code/integrity_validation/`: B1/B2 independent SHA-256 validation and harness assets.
- `code/p3a/`: userspace Merkle reference and native OpenSSL comparison benchmark.
- `data/`: reported results transcribed from EC2 console or prior manuscript.
  These are NOT a replacement for archived raw EC2 data.
- `evidence/`: provenance notices with original remote SHA-256 metadata.
- `provenance/checksums_sha256.txt`: calculated hashes of files in this package.
- `ec2_export/export_kernel_and_evidence.sh`: optional READ-ONLY script to collect
  the missing real kernel code and representative evidence after EC2 restart.

## Quick start (non-kernel)

```
python3 code/p3a/bpfseal_p3a_merkle_reference.py --steps 10000
# Needs libssl-dev and GCC on Ubuntu:
gcc -O2 -Wall -Wextra -std=c11 \
  -o /tmp/bpfseal_p3a_native_bench \
  code/p3a/bpfseal_p3a_native_bench.c -lcrypto
/tmp/bpfseal_p3a_native_bench 200000
```

The P1 benchmark requires the matching BPF-capable runtime and root rights.
The B2 independent verifier requires original trace files that remain on EC2.

## What not to claim

- No hardware-rooted or remote attestation was implemented.
- No complete cross-map dependency graph or hostile-kernel defense was demonstrated.
- No authorization-aware detection claim was validated.
- The 2007 no-hash ablation deliberately produces invalid commitments.
- Merkle userspace comparison is not kernel-level performance evidence.

For data interpretation and relevant prior work, see the separate manuscript.
