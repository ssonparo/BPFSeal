BPFSeal partial consolidation from conversation attachments. NOT a full backup of EC2 workspace.
Run collection/bpfseal_collect_ec2.py on the EC2 host to collect original experiments, logs, results and modified kernel files.
No experiment results are invented.
