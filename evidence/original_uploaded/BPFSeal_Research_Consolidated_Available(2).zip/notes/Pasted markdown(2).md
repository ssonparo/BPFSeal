**172-31-32-229**:**\~/bpfseal/kernel/linux-aws-7.0-bpfseal-patched**$ cd \~/bpfseal/kernel/linux-aws-7.0-bpfseal-patched



echo "=== FD MAP UPDATE CALLER ==="

sed -n '220,305p' kernel/bpf/syscall.c



echo "=== ARRAY AUX STRUCTURE ==="

rg -n -C 12 'struct bpf_array_aux|struct bpf_array \\{' \\

  include/linux/bpf.h kernel/bpf/arraymap.c



echo "=== PROGRAM ARRAY POKE OPERATIONS ==="

sed -n '1040,1165p' kernel/bpf/arraymap.c



echo "=== MAP COOKIE ASSIGNMENT ==="

rg -n -C 4 'map->cookie\s\*=|cookie =.\*map' \\

  kernel/bpf include/linux/bpf.h | head -90

\=== FD MAP UPDATE CALLER ===

&#x9;		err = -EFAULT;

&#x9;		goto unpin_all;

&#x9;	}



&#x9;	/\* The uptr's struct cannot span across two pages \*/

&#x9;	if ((start & PAGE_MASK) != (end & PAGE_MASK)) {

&#x9;		err = -EOPNOTSUPP;

&#x9;		goto unpin_all;

&#x9;	}



&#x9;	err = pin_user_pages_fast(start, 1, FOLL_LONGTERM | FOLL_WRITE, &page);

&#x9;	if (err != 1)

&#x9;		goto unpin_all;



&#x9;	if (PageHighMem(page)) {

&#x9;		err = -EOPNOTSUPP;

&#x9;		unpin_user_page(page);

&#x9;		goto unpin_all;

&#x9;	}



&#x9;	\*uptr_addr = page_address(page) + offset_in_page(start);

&#x9;}



&#x9;return 0;



unpin_all:

&#x9;\_\_bpf_obj_unpin_uptrs(rec, i, obj);

&#x9;return err;

}



static int bpf_map_update_value(struct bpf_map \*map, struct file \*map_file,

&#x9;			void \*key, void \*value, \_\_u64 flags)

{

&#x9;int err;



&#x9;/\* Need to create a kthread, thus must support schedule \*/

&#x9;if (bpf_map_is_offloaded(map)) {

&#x9;	return bpf_map_offload_update_elem(map, key, value, flags);

&#x9;} else if (map->map_type == BPF_MAP_TYPE_CPUMAP ||

&#x9;	   map->map_type == BPF_MAP_TYPE_ARENA ||

&#x9;	   map->map_type == BPF_MAP_TYPE_STRUCT_OPS) {

&#x9;	return map->ops->map_update_elem(map, key, value, flags);

&#x9;} else if (map->map_type == BPF_MAP_TYPE_SOCKHASH ||

&#x9;	   map->map_type == BPF_MAP_TYPE_SOCKMAP) {

&#x9;	return sock_map_update_elem_sys(map, key, value, flags);

&#x9;} else if (IS_FD_PROG_ARRAY(map)) {

&#x9;	return bpf_fd_array_map_update_elem(map, map_file, key, value,

&#x9;					    flags);

&#x9;}



&#x9;bpf_disable_instrumentation();

&#x9;if (map->map_type == BPF_MAP_TYPE_PERCPU_HASH ||

&#x9;    map->map_type == BPF_MAP_TYPE_LRU_PERCPU_HASH) {

&#x9;	err = bpf_percpu_hash_update(map, key, value, flags);

&#x9;} else if (map->map_type == BPF_MAP_TYPE_PERCPU_ARRAY) {

&#x9;	err = bpf_percpu_array_update(map, key, value, flags);

&#x9;} else if (map->map_type == BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE) {

&#x9;	err = bpf_percpu_cgroup_storage_update(map, key, value,

&#x9;					       flags);

&#x9;} else if (IS_FD_ARRAY(map)) {

&#x9;	err = bpf_fd_array_map_update_elem(map, map_file, key, value,

&#x9;					   flags);

&#x9;} else if (map->map_type == BPF_MAP_TYPE_HASH_OF_MAPS) {

&#x9;	err = bpf_fd_htab_map_update_elem(map, map_file, key, value,

&#x9;					  flags);

&#x9;} else if (map->map_type == BPF_MAP_TYPE_REUSEPORT_SOCKARRAY) {

&#x9;	/\* rcu_read_lock() is not needed \*/

&#x9;	err = bpf_fd_reuseport_array_update_elem(map, key, value,

&#x9;						 flags);

&#x9;} else if (map->map_type == BPF_MAP_TYPE_QUEUE ||

&#x9;	   map->map_type == BPF_MAP_TYPE_STACK ||

&#x9;	   map->map_type == BPF_MAP_TYPE_BLOOM_FILTER) {

&#x9;	err = map->ops->map_push_elem(map, value, flags);

&#x9;} else {

&#x9;	err = bpf_obj_pin_uptrs(map->record, value);

&#x9;	if (!err) {

&#x9;		rcu_read_lock();

&#x9;		err = map->ops->map_update_elem(map, key, value, flags);

&#x9;		rcu_read_unlock();

&#x9;		if (err)

&#x9;			bpf_obj_unpin_uptrs(map->record, value);

&#x9;	}

&#x9;}

&#x9;bpf_enable_instrumentation();



&#x9;return err;

\=== ARRAY AUX STRUCTURE ===

include/linux/bpf.h

1803-	u8 \_\_percpu		\*active;	/\* u8[BPF_NR_CONTEXTS] for recursion protection \*/

1804-	unsigned int		(\*bpf_func)(const void \*ctx,

1805-					    const struct bpf_insn \*insn);

1806-	struct bpf_prog_aux	\*aux;		/\* Auxiliary fields \*/

1807-	struct sock_fprog_kern	\*orig_prog;	/\* Original BPF program \*/

1808-	/\* Instructions for interpreter \*/

1809-	union {

1810-		DECLARE_FLEX_ARRAY(struct sock_filter, insns);

1811-		DECLARE_FLEX_ARRAY(struct bpf_insn, insnsi);

1812-	};

1813-};

1814-

1815:**struct bpf_array_aux** {

1816-	/\* Programs with direct jumps into programs part of this array. \*/

1817-	struct list_head poke_progs;

1818-	struct bpf_map \*map;

1819-	struct mutex poke_mutex;

1820-	struct work_struct work;

1821-};

1822-

1823-struct bpf_link {

1824-	atomic64_t refcnt;

1825-	u32 id;

1826-	enum bpf_link_type type;

1827-	const struct bpf_link_ops \*ops;

\--

2230-#else

2231-static inline int bpf_trampoline_link_cgroup_shim(struct bpf_prog \*prog,

2232-						  int cgroup_atype,

2233-						  enum bpf_attach_type attach_type)

2234-{

2235-	return -EOPNOTSUPP;

2236-}

2237-static inline void bpf_trampoline_unlink_cgroup_shim(struct bpf_prog \*prog)

2238-{

2239-}

2240-#endif

2241-

2242:**struct bpf_array {**

2243-	struct bpf_map map;

2244-	u32 elem_size;

2245-	u32 index_mask;

2246:	**struct bpf_array_aux** \*aux;

2247-	union {

2248-		DECLARE_FLEX_ARRAY(char, value) \_\_aligned(8);

2249-		DECLARE_FLEX_ARRAY(void \*, ptrs) \_\_aligned(8);

2250-		DECLARE_FLEX_ARRAY(void \_\_percpu \*, pptrs) \_\_aligned(8);

2251-	};

2252-};

2253-

2254-/\*

2255- \* The bpf_array_get_next_key() function may be used for all array-like

2256- \* maps, i.e., maps with u32 keys with range [0 ,..., max_entries)

2257- \*/

2258-int bpf_array_get_next_key(struct bpf_map \*map, void \*key, void \*next_key);



kernel/bpf/arraymap.c

1062-	rcu_read_unlock();

1063-}

1064-

1065-struct prog_poke_elem {

1066-	struct list_head list;

1067-	struct bpf_prog_aux \*aux;

1068-};

1069-

1070-static int prog_array_map_poke_track(struct bpf_map \*map,

1071-				     struct bpf_prog_aux \*prog_aux)

1072-{

1073-	struct prog_poke_elem \*elem;

1074:	**struct bpf_array_aux** \*aux;

1075-	int ret = 0;

1076-

1077-	aux = container_of(map, struct bpf_array, map)->aux;

1078-	mutex_lock(&aux->poke_mutex);

1079-	list_for_each_entry(elem, &aux->poke_progs, list) {

1080-		if (elem->aux == prog_aux)

1081-			goto out;

1082-	}

1083-

1084-	elem = kmalloc_obj(\*elem);

1085-	if (!elem) {

1086-		ret = -ENOMEM;

\--

1095-	elem->aux = prog_aux;

1096-

1097-	list_add_tail(&elem->list, &aux->poke_progs);

1098-out:

1099-	mutex_unlock(&aux->poke_mutex);

1100-	return ret;

1101-}

1102-

1103-static void prog_array_map_poke_untrack(struct bpf_map \*map,

1104-					struct bpf_prog_aux \*prog_aux)

1105-{

1106-	struct prog_poke_elem \*elem, \*tmp;

1107:	**struct bpf_array_aux** \*aux;

1108-

1109-	aux = container_of(map, struct bpf_array, map)->aux;

1110-	mutex_lock(&aux->poke_mutex);

1111-	list_for_each_entry_safe(elem, tmp, &aux->poke_progs, list) {

1112-		if (elem->aux == prog_aux) {

1113-			list_del_init(&elem->list);

1114-			kfree(elem);

1115-			break;

1116-		}

1117-	}

1118-	mutex_unlock(&aux->poke_mutex);

1119-}

1120-

1121-void \_\_weak bpf_arch_poke_desc_update(struct bpf_jit_poke_descriptor \*poke,

1122-				      struct bpf_prog \*new, struct bpf_prog \*old)

1123-{

1124-	WARN_ON_ONCE(1);

1125-}

1126-

1127-static void prog_array_map_poke_run(struct bpf_map \*map, u32 key,

1128-				    struct bpf_prog \*old,

1129-				    struct bpf_prog \*new)

1130-{

1131-	struct prog_poke_elem \*elem;

1132:	**struct bpf_array_aux** \*aux;

1133-

1134-	aux = container_of(map, struct bpf_array, map)->aux;

1135-	WARN_ON_ONCE(!mutex_is_locked(&aux->poke_mutex));

1136-

1137-	list_for_each_entry(elem, &aux->poke_progs, list) {

1138-		struct bpf_jit_poke_descriptor \*poke;

1139-		int i;

1140-

1141-		for (i = 0; i < elem->aux->size_poke_tab; i++) {

1142-			poke = &elem->aux->poke_tab[i];

1143-

1144-			/\* Few things to be aware of:

\--

1166-				continue;

1167-			if (poke->tail_call.map != map ||

1168-			    poke->tail_call.key != key)

1169-				continue;

1170-

1171-			bpf_arch_poke_desc_update(poke, new, old);

1172-		}

1173-	}

1174-}

1175-

1176-static void prog_array_map_clear_deferred(struct work_struct \*work)

1177-{

1178:	struct bpf_map \*map = container_of(work, **struct bpf_array_aux**,

1179-					   work)->map;

1180-	bpf_fd_array_map_clear(map, true);

1181-	bpf_map_put(map);

1182-}

1183-

1184-static void prog_array_map_clear(struct bpf_map \*map)

1185-{

1186:	**struct bpf_array_aux** \*aux = container_of(map, struct bpf_array,

1187-						 map)->aux;

1188-	bpf_map_inc(map);

1189-	schedule_work(&aux->work);

1190-}

1191-

1192-static struct bpf_map \*prog_array_map_alloc(union bpf_attr \*attr)

1193-{

1194:	**struct bpf_array_aux** \*aux;

1195-	struct bpf_map \*map;

1196-

1197-	aux = kzalloc_obj(\*aux, GFP_KERNEL_ACCOUNT);

1198-	if (!aux)

1199-		return ERR_PTR(-ENOMEM);

1200-

1201-	INIT_WORK(&aux->work, prog_array_map_clear_deferred);

1202-	INIT_LIST_HEAD(&aux->poke_progs);

1203-	mutex_init(&aux->poke_mutex);

1204-

1205-	map = array_map_alloc(attr);

1206-	if (IS_ERR(map)) {

\--

1208-		return map;

1209-	}

1210-

1211-	container_of(map, struct bpf_array, map)->aux = aux;

1212-	aux->map = map;

1213-

1214-	return map;

1215-}

1216-

1217-static void prog_array_map_free(struct bpf_map \*map)

1218-{

1219-	struct prog_poke_elem \*elem, \*tmp;

1220:	**struct bpf_array_aux** \*aux;

1221-

1222-	aux = container_of(map, struct bpf_array, map)->aux;

1223-	list_for_each_entry_safe(elem, tmp, &aux->poke_progs, list) {

1224-		list_del_init(&elem->list);

1225-		kfree(elem);

1226-	}

1227-	kfree(aux);

1228-	fd_array_map_free(map);

1229-}

1230-

1231-/\* prog_array->aux->{type,jited} is a runtime binding.

1232- \* Doing static check alone in the verifier is not enough.

\=== PROGRAM ARRAY POKE OPERATIONS ===

}



static void prog_array_map_seq_show_elem(struct bpf_map \*map, void \*key,

&#x9;				 struct seq_file \*m)

{

&#x9;void \*\*elem, \*ptr;

&#x9;u32 prog_id;



&#x9;rcu_read_lock();



&#x9;elem = array_map_lookup_elem(map, key);

&#x9;if (elem) {

&#x9;	ptr = READ_ONCE(\*elem);

&#x9;	if (ptr) {

&#x9;		seq_printf(m, "%u: ", \*(u32 \*)key);

&#x9;		prog_id = prog_fd_array_sys_lookup_elem(ptr);

&#x9;		btf_type_seq_show(map->btf, map->btf_value_type_id,

&#x9;				  &prog_id, m);

&#x9;		seq_putc(m, '\n');

&#x9;	}

&#x9;}



&#x9;rcu_read_unlock();

}



struct prog_poke_elem {

&#x9;struct list_head list;

&#x9;struct bpf_prog_aux \*aux;

};



static int prog_array_map_poke_track(struct bpf_map \*map,

&#x9;			     struct bpf_prog_aux \*prog_aux)

{

&#x9;struct prog_poke_elem \*elem;

&#x9;struct bpf_array_aux \*aux;

&#x9;int ret = 0;



&#x9;aux = container_of(map, struct bpf_array, map)->aux;

&#x9;mutex_lock(&aux->poke_mutex);

&#x9;list_for_each_entry(elem, &aux->poke_progs, list) {

&#x9;	if (elem->aux == prog_aux)

&#x9;		goto out;

&#x9;}



&#x9;elem = kmalloc_obj(\*elem);

&#x9;if (!elem) {

&#x9;	ret = -ENOMEM;

&#x9;	goto out;

&#x9;}



&#x9;INIT_LIST_HEAD(&elem->list);

&#x9;/\* We must track the program's aux info at this point in time

&#x9; \* since the program pointer itself may not be stable yet, see

&#x9; \* also comment in prog_array_map_poke_run().

&#x9; \*/

&#x9;elem->aux = prog_aux;



&#x9;list_add_tail(&elem->list, &aux->poke_progs);

out:

&#x9;mutex_unlock(&aux->poke_mutex);

&#x9;return ret;

}



static void prog_array_map_poke_untrack(struct bpf_map \*map,

&#x9;				struct bpf_prog_aux \*prog_aux)

{

&#x9;struct prog_poke_elem \*elem, \*tmp;

&#x9;struct bpf_array_aux \*aux;



&#x9;aux = container_of(map, struct bpf_array, map)->aux;

&#x9;mutex_lock(&aux->poke_mutex);

&#x9;list_for_each_entry_safe(elem, tmp, &aux->poke_progs, list) {

&#x9;	if (elem->aux == prog_aux) {

&#x9;		list_del_init(&elem->list);

&#x9;		kfree(elem);

&#x9;		break;

&#x9;	}

&#x9;}

&#x9;mutex_unlock(&aux->poke_mutex);

}



void \_\_weak bpf_arch_poke_desc_update(struct bpf_jit_poke_descriptor \*poke,

&#x9;			      struct bpf_prog \*new, struct bpf_prog \*old)

{

&#x9;WARN_ON_ONCE(1);

}



static void prog_array_map_poke_run(struct bpf_map \*map, u32 key,

&#x9;			    struct bpf_prog \*old,

&#x9;			    struct bpf_prog \*new)

{

&#x9;struct prog_poke_elem \*elem;

&#x9;struct bpf_array_aux \*aux;



&#x9;aux = container_of(map, struct bpf_array, map)->aux;

&#x9;WARN_ON_ONCE(!mutex_is_locked(&aux->poke_mutex));



&#x9;list_for_each_entry(elem, &aux->poke_progs, list) {

&#x9;	struct bpf_jit_poke_descriptor \*poke;

&#x9;	int i;



&#x9;	for (i = 0; i < elem->aux->size_poke_tab; i++) {

&#x9;		poke = &elem->aux->poke_tab[i];



&#x9;		/\* Few things to be aware of:

&#x9;		 \*

&#x9;		 \* 1) We can only ever access aux in this context, but

&#x9;		 \*    not aux->prog since it might not be stable yet and

&#x9;		 \*    there could be danger of use after free otherwise.

&#x9;		 \* 2) Initially when we start tracking aux, the program

&#x9;		 \*    is not JITed yet and also does not have a kallsyms

&#x9;		 \*    entry. We skip these as poke->tailcall_target_stable

&#x9;		 \*    is not active yet. The JIT will do the final fixup

&#x9;		 \*    before setting it stable. The various

&#x9;		 \*    poke->tailcall_target_stable are successively

&#x9;		 \*    activated, so tail call updates can arrive from here

&#x9;		 \*    while JIT is still finishing its final fixup for

&#x9;		 \*    non-activated poke entries.

&#x9;		 \* 3) Also programs reaching refcount of zero while patching

&#x9;		 \*    is in progress is okay since we're protected under

&#x9;		 \*    poke_mutex and untrack the programs before the JIT

&#x9;		 \*    buffer is freed.

&#x9;		 \*/

&#x9;		if (!READ_ONCE(poke->tailcall_target_stable))

&#x9;			continue;

&#x9;		if (poke->reason != BPF_POKE_REASON_TAIL_CALL)

\=== MAP COOKIE ASSIGNMENT ===

kernel/bpf/syscall.c-1522-	if (err < 0)

kernel/bpf/syscall.c-1523-		goto free_map;

kernel/bpf/syscall.c-1524-

kernel/bpf/syscall.c-1525-	preempt_disable();

kernel/bpf/syscall.c:1526:	map->cookie = gen_cookie_next(&bpf_map_cookie);

kernel/bpf/syscall.c-1527-	preempt_enable();

kernel/bpf/syscall.c-1528-

kernel/bpf/syscall.c-1529-	atomic64_set(&map->refcnt, 1);

kernel/bpf/syscall.c-1530-	atomic64_set(&map->usercnt, 1);

**ubuntu\@ip-172-31-32-229**:**\~/bpfseal/kernel/linux-aws-7.0-bpfseal-patched**$