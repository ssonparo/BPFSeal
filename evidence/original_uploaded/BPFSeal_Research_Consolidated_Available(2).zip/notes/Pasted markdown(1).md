rning: behavior of -n is non-portable and may change in future; use --update=none instead

**ubuntu\@ip-172-31-32-229**:**\~/bpfseal**$ cd \~/bpfseal/kernel/linux-aws-7.0-bpfseal-build



echo "=== PROG_ARRAY CALLBACKS ==="

sed -n '900,1030p' kernel/bpf/arraymap.c

sed -n '1150,1245p' kernel/bpf/arraymap.c



echo "=== MAP UPDATE / DELETE ==="

rg -n 'array_map_update_elem|array_map_delete_elem|map_fd_put_ptr|map_fd_get_ptr' \\

  kernel/bpf/arraymap.c



echo "=== PROGRAM LOAD FINALIZATION ==="

sed -n '3080,3155p' kernel/bpf/syscall.c



echo "=== LINK UPDATE ==="

sed -n '5860,5980p' kernel/bpf/syscall.c

\=== PROG_ARRAY CALLBACKS ===

int bpf_fd_array_map_update_elem(struct bpf_map \*map, struct file \*map_file,

&#x9;			 void \*key, void \*value, u64 map_flags)

{

&#x9;struct bpf_array \*array = container_of(map, struct bpf_array, map);

&#x9;void \*new_ptr, \*old_ptr;

&#x9;u32 index = \*(u32 \*)key, ufd;



&#x9;if (map_flags != BPF_ANY)

&#x9;	return -EINVAL;



&#x9;if (index >= array->map.max_entries)

&#x9;	return -E2BIG;



&#x9;ufd = \*(u32 \*)value;

&#x9;new_ptr = map->ops->map_fd_get_ptr(map, map_file, ufd);

&#x9;if (IS_ERR(new_ptr))

&#x9;	return PTR_ERR(new_ptr);



&#x9;if (map->ops->map_poke_run) {

&#x9;	mutex_lock(&array->aux->poke_mutex);

&#x9;	old_ptr = xchg(array->ptrs + index, new_ptr);

&#x9;	map->ops->map_poke_run(map, index, old_ptr, new_ptr);

&#x9;	mutex_unlock(&array->aux->poke_mutex);

&#x9;} else {

&#x9;	old_ptr = xchg(array->ptrs + index, new_ptr);

&#x9;}



&#x9;if (old_ptr)

&#x9;	map->ops->map_fd_put_ptr(map, old_ptr, true);

&#x9;return 0;

}



static long \_\_fd_array_map_delete_elem(struct bpf_map \*map, void \*key, bool need_defer)

{

&#x9;struct bpf_array \*array = container_of(map, struct bpf_array, map);

&#x9;void \*old_ptr;

&#x9;u32 index = \*(u32 \*)key;



&#x9;if (index >= array->map.max_entries)

&#x9;	return -E2BIG;



&#x9;if (map->ops->map_poke_run) {

&#x9;	mutex_lock(&array->aux->poke_mutex);

&#x9;	old_ptr = xchg(array->ptrs + index, NULL);

&#x9;	map->ops->map_poke_run(map, index, old_ptr, NULL);

&#x9;	mutex_unlock(&array->aux->poke_mutex);

&#x9;} else {

&#x9;	old_ptr = xchg(array->ptrs + index, NULL);

&#x9;}



&#x9;if (old_ptr) {

&#x9;	map->ops->map_fd_put_ptr(map, old_ptr, need_defer);

&#x9;	return 0;

&#x9;} else {

&#x9;	return -ENOENT;

&#x9;}

}



static long fd_array_map_delete_elem(struct bpf_map \*map, void \*key)

{

&#x9;return \_\_fd_array_map_delete_elem(map, key, true);

}



static void \*prog_fd_array_get_ptr(struct bpf_map \*map,

&#x9;			   struct file \*map_file, int fd)

{

&#x9;struct bpf_prog \*prog = bpf_prog_get(fd);

&#x9;bool is_extended;



&#x9;if (IS_ERR(prog))

&#x9;	return prog;



&#x9;if (prog->type == BPF_PROG_TYPE_EXT ||

&#x9;    !bpf_prog_map_compatible(map, prog)) {

&#x9;	bpf_prog_put(prog);

&#x9;	return ERR_PTR(-EINVAL);

&#x9;}



&#x9;mutex_lock(&prog->aux->ext_mutex);

&#x9;is_extended = prog->aux->is_extended;

&#x9;if (!is_extended)

&#x9;	prog->aux->prog_array_member_cnt++;

&#x9;mutex_unlock(&prog->aux->ext_mutex);

&#x9;if (is_extended) {

&#x9;	/\* Extended prog can not be tail callee. It's to prevent a

&#x9;	 \* potential infinite loop like:

&#x9;	 \* tail callee prog entry -> tail callee prog subprog ->

&#x9;	 \* freplace prog entry --tailcall-> tail callee prog entry.

&#x9;	 \*/

&#x9;	bpf_prog_put(prog);

&#x9;	return ERR_PTR(-EBUSY);

&#x9;}



&#x9;return prog;

}



static void prog_fd_array_put_ptr(struct bpf_map \*map, void \*ptr, bool need_defer)

{

&#x9;struct bpf_prog \*prog = ptr;



&#x9;mutex_lock(&prog->aux->ext_mutex);

&#x9;prog->aux->prog_array_member_cnt--;

&#x9;mutex_unlock(&prog->aux->ext_mutex);

&#x9;/\* bpf_prog is freed after one RCU or tasks trace grace period \*/

&#x9;bpf_prog_put(prog);

}



static u32 prog_fd_array_sys_lookup_elem(void \*ptr)

{

&#x9;return ((struct bpf_prog \*)ptr)->aux->id;

}



/\* decrement refcnt of all bpf_progs that are stored in this map \*/

static void bpf_fd_array_map_clear(struct bpf_map \*map, bool need_defer)

{

&#x9;struct bpf_array \*array = container_of(map, struct bpf_array, map);

&#x9;int i;



&#x9;for (i = 0; i < array->map.max_entries; i++) {

&#x9;	\_\_fd_array_map_delete_elem(map, &i, need_defer);

&#x9;	cond_resched();

&#x9;}

}



static void prog_array_map_seq_show_elem(struct bpf_map \*map, void \*key,

&#x9;				 struct seq_file \*m)

{

&#x9;void \*\*elem, \*ptr;

&#x9;u32 prog_id;



&#x9;rcu_read_lock();

&#x9;		    poke->tail_call.key != key)

&#x9;			continue;



&#x9;		bpf_arch_poke_desc_update(poke, new, old);

&#x9;	}

&#x9;}

}



static void prog_array_map_clear_deferred(struct work_struct \*work)

{

&#x9;struct bpf_map \*map = container_of(work, struct bpf_array_aux,

&#x9;				   work)->map;

&#x9;bpf_fd_array_map_clear(map, true);

&#x9;bpf_map_put(map);

}



static void prog_array_map_clear(struct bpf_map \*map)

{

&#x9;struct bpf_array_aux \*aux = container_of(map, struct bpf_array,

&#x9;					 map)->aux;

&#x9;bpf_map_inc(map);

&#x9;schedule_work(&aux->work);

}



static struct bpf_map \*prog_array_map_alloc(union bpf_attr \*attr)

{

&#x9;struct bpf_array_aux \*aux;

&#x9;struct bpf_map \*map;



&#x9;aux = kzalloc_obj(\*aux, GFP_KERNEL_ACCOUNT);

&#x9;if (!aux)

&#x9;	return ERR_PTR(-ENOMEM);



&#x9;INIT_WORK(&aux->work, prog_array_map_clear_deferred);

&#x9;INIT_LIST_HEAD(&aux->poke_progs);

&#x9;mutex_init(&aux->poke_mutex);



&#x9;map = array_map_alloc(attr);

&#x9;if (IS_ERR(map)) {

&#x9;	kfree(aux);

&#x9;	return map;

&#x9;}



&#x9;container_of(map, struct bpf_array, map)->aux = aux;

&#x9;aux->map = map;



&#x9;return map;

}



static void prog_array_map_free(struct bpf_map \*map)

{

&#x9;struct prog_poke_elem \*elem, \*tmp;

&#x9;struct bpf_array_aux \*aux;



&#x9;aux = container_of(map, struct bpf_array, map)->aux;

&#x9;list_for_each_entry_safe(elem, tmp, &aux->poke_progs, list) {

&#x9;	list_del_init(&elem->list);

&#x9;	kfree(elem);

&#x9;}

&#x9;kfree(aux);

&#x9;fd_array_map_free(map);

}



/\* prog_array->aux->{type,jited} is a runtime binding.

 \* Doing static check alone in the verifier is not enough.

 \* Thus, prog_array_map cannot be used as an inner_map

 \* and map_meta_equal is not implemented.

 \*/

const struct bpf_map_ops prog_array_map_ops = {

&#x9;.map_alloc_check = fd_array_map_alloc_check,

&#x9;.map_alloc = prog_array_map_alloc,

&#x9;.map_free = prog_array_map_free,

&#x9;.map_poke_track = prog_array_map_poke_track,

&#x9;.map_poke_untrack = prog_array_map_poke_untrack,

&#x9;.map_poke_run = prog_array_map_poke_run,

&#x9;.map_get_next_key = bpf_array_get_next_key,

&#x9;.map_lookup_elem = fd_array_map_lookup_elem,

&#x9;.map_delete_elem = fd_array_map_delete_elem,

&#x9;.map_fd_get_ptr = prog_fd_array_get_ptr,

&#x9;.map_fd_put_ptr = prog_fd_array_put_ptr,

&#x9;.map_fd_sys_lookup_elem = prog_fd_array_sys_lookup_elem,

&#x9;.map_release_uref = prog_array_map_clear,

&#x9;.map_seq_show_elem = prog_array_map_seq_show_elem,

&#x9;.map_mem_usage = array_map_mem_usage,

&#x9;.map_btf_id = &array_map_btf_ids[0],

};



static struct bpf_event_entry \*bpf_event_entry_gen(struct file \*perf_file,

&#x9;					   struct file \*map_file)

{

&#x9;struct bpf_event_entry \*ee;



&#x9;ee = kzalloc_obj(\*ee);

&#x9;if (ee) {

&#x9;	ee->event = perf_file->private_data;

&#x9;	ee->perf_file = perf_file;

\=== MAP UPDATE / DELETE ===

363:static long **array_map_update_elem**(struct bpf_map \*map, void \*key, void \*value,

452:static long **array_map_delete_elem**(struct bpf_map \*map, void \*key)

811:	.map_update_elem = **array_map_update_elem**,

812:	.map_delete_elem = **array_map_delete_elem**,

837:	.map_update_elem = **array_map_update_elem**,

838:	.map_delete_elem = **array_map_delete_elem**,

900:int bpf_fd\_**array_map_update_elem**(struct bpf_map \*map, struct file \*map_file,

914:	new_ptr = map->ops->**map_fd_get_ptr**(map, map_file, ufd);

928:		map->ops->**map_fd_put_ptr**(map, old_ptr, true);

932:static long \_\_fd\_**array_map_delete_elem**(struct bpf_map \*map, void \*key, bool need_defer)

951:		map->ops->**map_fd_put_ptr**(map, old_ptr, need_defer);

958:static long fd\_**array_map_delete_elem**(struct bpf_map \*map, void \*key)

960:	return \_\_fd\_**array_map_delete_elem**(map, key, true);

1019:		\_\_fd\_**array_map_delete_elem**(map, &i, need_defer);

1227:	.map_delete_elem = fd\_**array_map_delete_elem**,

1228:	.**map_fd_get_ptr** = prog_fd_array_get_ptr,

1229:	.**map_fd_put_ptr** = prog_fd_array_put_ptr,

1312:			\_\_fd\_**array_map_delete_elem**(map, &i, true);

1331:	.map_delete_elem = fd\_**array_map_delete_elem**,

1332:	.**map_fd_get_ptr** = perf_event_fd_array_get_ptr,

1333:	.**map_fd_put_ptr** = perf_event_fd_array_put_ptr,

1367:	.map_delete_elem = fd\_**array_map_delete_elem**,

1368:	.**map_fd_get_ptr** = cgroup_fd_array_get_ptr,

1369:	.**map_fd_put_ptr** = cgroup_fd_array_put_ptr,

1452:	.map_delete_elem = fd\_**array_map_delete_elem**,

1453:	.**map_fd_get_ptr** = bpf\_**map_fd_get_ptr**,

1454:	.**map_fd_put_ptr** = bpf\_**map_fd_put_ptr**,

\=== PROGRAM LOAD FINALIZATION ===

&#x9;if (type == BPF_PROG_TYPE_TRACING && dst_prog &&

&#x9;    dst_prog->type == BPF_PROG_TYPE_TRACING) {

&#x9;	prog->aux->attach_tracing_prog = true;

&#x9;}



&#x9;/\* find program type: socket_filter vs tracing_filter \*/

&#x9;err = find_prog_type(type, prog);

&#x9;if (err < 0)

&#x9;	goto free_prog;



&#x9;prog->aux->load_time = ktime_get_boottime_ns();

&#x9;err = bpf_obj_name_cpy(prog->aux->name, attr->prog_name,

&#x9;		       sizeof(attr->prog_name));

&#x9;if (err < 0)

&#x9;	goto free_prog;



&#x9;err = security_bpf_prog_load(prog, attr, token, uattr.is_kernel);

&#x9;if (err)

&#x9;	goto free_prog_sec;



&#x9;/\* run eBPF verifier \*/

&#x9;err = bpf_check(&prog, attr, uattr, uattr_size);

&#x9;if (err < 0)

&#x9;	goto free_used_maps;



&#x9;prog = bpf_prog_select_runtime(prog, &err);

&#x9;if (err < 0)

&#x9;	goto free_used_maps;



&#x9;err = bpf_prog_mark_insn_arrays_ready(prog);

&#x9;if (err < 0)

&#x9;	goto free_used_maps;



&#x9;err = bpf_prog_alloc_id(prog);

&#x9;if (err)

&#x9;	goto free_used_maps;



&#x9;/\* Upon success of bpf_prog_alloc_id(), the BPF prog is

&#x9; \* effectively publicly exposed. However, retrieving via

&#x9; \* bpf_prog_get_fd_by_id() will take another reference,

&#x9; \* therefore it cannot be gone underneath us.

&#x9; \*

&#x9; \* Only for the time /after/ successful bpf_prog_new_fd()

&#x9; \* and before returning to userspace, we might just hold

&#x9; \* one reference and any parallel close on that fd could

&#x9; \* rip everything out. Hence, below notifications must

&#x9; \* happen before bpf_prog_new_fd().

&#x9; \*

&#x9; \* Also, any failure handling from this point onwards must

&#x9; \* be using bpf_prog_put() given the program is exposed.

&#x9; \*/

&#x9;bpf_prog_kallsyms_add(prog);

&#x9;perf_event_bpf_event(prog, PERF_BPF_EVENT_PROG_LOAD, 0);

&#x9;bpf_audit_prog(prog, BPF_AUDIT_LOAD);



&#x9;err = bpf_prog_new_fd(prog);

&#x9;if (err < 0)

&#x9;	bpf_prog_put(prog);

&#x9;return err;



free_used_maps:

&#x9;/\* In case we have subprogs, we need to wait for a grace

&#x9; \* period before we can tear down JIT memory since symbols

&#x9; \* are already exposed under kallsyms.

&#x9; \*/

&#x9;\_\_bpf_prog_put_noref(prog, prog->aux->real_func_cnt);

&#x9;return err;



free_prog_sec:

&#x9;security_bpf_prog_free(prog);

free_prog:

&#x9;free_uid(prog->aux->user);

&#x9;if (prog->aux->attach_btf)

&#x9;	btf_put(prog->aux->attach_btf);

&#x9;bpf_prog_free(prog);

put_token:

\=== LINK UPDATE ===

&#x9;	bpf_map_put(old_map);

out_put:

&#x9;bpf_map_put(new_map);

&#x9;return ret;

}



\#define BPF_LINK_UPDATE_LAST_FIELD link_update.old_prog_fd



static int link_update(union bpf_attr \*attr)

{

&#x9;struct bpf_prog \*old_prog = NULL, \*new_prog;

&#x9;struct bpf_link \*link;

&#x9;u32 flags;

&#x9;int ret;



&#x9;if (CHECK_ATTR(BPF_LINK_UPDATE))

&#x9;	return -EINVAL;



&#x9;flags = attr->link_update.flags;

&#x9;if (flags & \~BPF_F_REPLACE)

&#x9;	return -EINVAL;



&#x9;link = bpf_link_get_from_fd(attr->link_update.link_fd);

&#x9;if (IS_ERR(link))

&#x9;	return PTR_ERR(link);



&#x9;if (link->ops->update_map) {

&#x9;	ret = link_update_map(link, attr);

&#x9;	goto out_put_link;

&#x9;}



&#x9;new_prog = bpf_prog_get(attr->link_update.new_prog_fd);

&#x9;if (IS_ERR(new_prog)) {

&#x9;	ret = PTR_ERR(new_prog);

&#x9;	goto out_put_link;

&#x9;}



&#x9;if (flags & BPF_F_REPLACE) {

&#x9;	old_prog = bpf_prog_get(attr->link_update.old_prog_fd);

&#x9;	if (IS_ERR(old_prog)) {

&#x9;		ret = PTR_ERR(old_prog);

&#x9;		old_prog = NULL;

&#x9;		goto out_put_progs;

&#x9;	}

&#x9;} else if (attr->link_update.old_prog_fd) {

&#x9;	ret = -EINVAL;

&#x9;	goto out_put_progs;

&#x9;}



&#x9;if (link->ops->update_prog)

&#x9;	ret = link->ops->update_prog(link, new_prog, old_prog);

&#x9;else

&#x9;	ret = -EINVAL;



out_put_progs:

&#x9;if (old_prog)

&#x9;	bpf_prog_put(old_prog);

&#x9;if (ret)

&#x9;	bpf_prog_put(new_prog);

out_put_link:

&#x9;bpf_link_put_direct(link);

&#x9;return ret;

}



\#define BPF_LINK_DETACH_LAST_FIELD link_detach.link_fd



static int link_detach(union bpf_attr \*attr)

{

&#x9;struct bpf_link \*link;

&#x9;int ret;



&#x9;if (CHECK_ATTR(BPF_LINK_DETACH))

&#x9;	return -EINVAL;



&#x9;link = bpf_link_get_from_fd(attr->link_detach.link_fd);

&#x9;if (IS_ERR(link))

&#x9;	return PTR_ERR(link);



&#x9;if (link->ops->detach)

&#x9;	ret = link->ops->detach(link);

&#x9;else

&#x9;	ret = -EOPNOTSUPP;



&#x9;bpf_link_put_direct(link);

&#x9;return ret;

}



struct bpf_link \*bpf_link_inc_not_zero(struct bpf_link \*link)

{

&#x9;return atomic64_fetch_add_unless(&link->refcnt, 1, 0) ? link : ERR_PTR(-ENOENT);

}

EXPORT_SYMBOL(bpf_link_inc_not_zero);



struct bpf_link \*bpf_link_by_id(u32 id)

{

&#x9;struct bpf_link \*link;



&#x9;if (!id)

&#x9;	return ERR_PTR(-ENOENT);



&#x9;spin_lock_bh(&link_idr_lock);

&#x9;/\* before link is "settled", ID is 0, pretend it doesn't exist yet \*/

&#x9;link = idr_find(&link_idr, id);

&#x9;if (link) {

&#x9;	if (link->id)

&#x9;		link = bpf_link_inc_not_zero(link);

&#x9;	else

&#x9;		link = ERR_PTR(-EAGAIN);

&#x9;} else {

&#x9;	link = ERR_PTR(-ENOENT);

&#x9;}

&#x9;spin_unlock_bh(&link_idr_lock);

&#x9;return link;

}



struct bpf_link \*bpf_link_get_curr_or_next(u32 \*id)

{

&#x9;struct bpf_link \*link;



&#x9;spin_lock_bh(&link_idr_lock);

again:

**ubuntu\@ip-172-31-32-229**:**\~/bpfseal/kernel/linux-aws-7.0-bpfseal-build**$ cd \~/bpfseal/kernel



cp -a linux-aws-7.0-bpfseal-build \\

  linux-aws-7.0-bpfseal-patched


