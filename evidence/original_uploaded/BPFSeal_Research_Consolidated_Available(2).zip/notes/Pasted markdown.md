**-build**$ echo "=== ACTIVE PACKAGING ==="

readlink -f debian



echo "=== ACTIVE CHANGELOG ==="

head -5 debian/changelog



echo "=== AWS CHANGELOG ==="

head -5 debian.aws/changelog



echo "=== BUILD TARGETS ==="

grep -nE '^([[:alnum:]\_.%/-]+):' \\

  debian/rules debian/rules.d/\*.mk | \\

  grep -E 'binary|build|clean' | head -45

\=== ACTIVE PACKAGING ===

/home/ubuntu/bpfseal/kernel/linux-aws-7.0-bpfseal-build/debian

\=== ACTIVE CHANGELOG ===

linux-aws-7.0 (7.0.0-1014.14\~24.04.1) noble; urgency=medium



  \* noble/linux-aws-7.0: 7.0.0-1014.14\~24.04.1 -proposed tracker (LP: #2165457)



  [ Ubuntu-aws: 7.0.0-1014.14 ]

\=== AWS CHANGELOG ===

linux-aws (7.0.0-1014.14) resolute; urgency=medium



  \* resolute/linux-aws: 7.0.0-1014.14 -proposed tracker (LP: #2165458)



  \* resolute: llvm-21-dev build-depends breaks cross-builds (LP: #2165407)

\=== BUILD TARGETS ===

debian/rules:127:.PHONY: binary

debian/rules:128:binary: binary-indep binary-arch

debian/rules:130:.PHONY: build

debian/rules:131:build: build-arch build-indep

debian/rules:133:.PHONY: clean

debian/rules:134:clean: debian/control debian/canonical-certs.pem debian/canonical-revoked-certs.pem

debian/rules:152:.PHONY: distclean

debian/rules:153:distclean: clean

debian/rules.d/2-binary-arch.mk:27:debian/scripts/fix-filenames: debian/scripts/fix-filenames.c

debian/rules.d/2-binary-arch.mk:46:prepare-%: $(stampdir)/stamp-prepare-%

debian/rules.d/2-binary-arch.mk:49:build-%: $(stampdir)/stamp-install-%

debian/rules.d/2-binary-arch.mk:513:.PHONY: binary-arch-headers

debian/rules.d/2-binary-arch.mk:514:binary-arch-headers: $(stampdir)/stamp-install-arch-headers

debian/rules.d/2-binary-arch.mk:521:binary-%: pkgimg = $(bin_pkg_name)-$\*

debian/rules.d/2-binary-arch.mk:522:binary-%: pkgimg_mods = $(mods_pkg_name)-$\*

debian/rules.d/2-binary-arch.mk:523:binary-%: pkgbldinfo = $(bldinfo_pkg_name)-$\*

debian/rules.d/2-binary-arch.mk:524:binary-%: pkghdr = $(hdrs_pkg_name)-$\*

debian/rules.d/2-binary-arch.mk:525:binary-%: pkgrust = $(rust_pkg_name)-$\*

debian/rules.d/2-binary-arch.mk:526:binary-%: dbgpkg = $(bin_pkg_name)-$\*-dbgsym

debian/rules.d/2-binary-arch.mk:527:binary-%: dbgpkgdir = $(CURDIR)/debian/$(bin_pkg_name)-$\*-dbgsym

debian/rules.d/2-binary-arch.mk:528:binary-%: pkgtools = $(tools_flavour_pkg_name)-$\*

debian/rules.d/2-binary-arch.mk:529:binary-%: pkgcloud = $(cloud_flavour_pkg_name)-$\*

debian/rules.d/2-binary-arch.mk:533:binary-%: rprovides = $(foreach \_m,$(all_built-in_dkms_modules),$(if $(enable\_$(\_m)),$(foreach \_r,$(dkms\_$(\_m)\_rprovides),$(\_r)$(comma) )))

debian/rules.d/2-binary-arch.mk:534:binary-%: $(stampdir)/stamp-install-%

debian/rules.d/2-binary-arch.mk:649:.PHONY: install-perarch

debian/rules.d/2-binary-arch.mk:650:install-perarch: toolspkgdir = $(CURDIR)/debian/$(tools_pkg_name)

debian/rules.d/2-binary-arch.mk:651:install-perarch: cloudpkgdir = $(CURDIR)/debian/$(cloud_pkg_name)

debian/rules.d/2-binary-arch.mk:652:install-perarch: bpftoolpkgdir = $(CURDIR)/debian/$(bpftool_pkg_name)

debian/rules.d/2-binary-arch.mk:653:install-perarch: perfpkgdir = $(CURDIR)/debian/$(perf_pkg_name)

debian/rules.d/2-binary-arch.mk:655:install-perarch: perfinstalldir = $(toolspkgdir)/usr/lib/$(DEB_SOURCE)-tools-$(abi_release)

debian/rules.d/2-binary-arch.mk:656:install-perarch: perfjvmtiinstalldir = $(perfinstalldir)

debian/rules.d/2-binary-arch.mk:657:install-perarch: perfpythoninstalldir = $(perfinstalldir)/lib

debian/rules.d/2-binary-arch.mk:658:install-perarch: bpftoolinstalldir = $(toolspkgdir)/usr/lib/$(DEB_SOURCE)-tools-$(abi_release)

debian/rules.d/2-binary-arch.mk:660:install-perarch: perfinstalldir = $(perfpkgdir)/usr/bin

debian/rules.d/2-binary-arch.mk:661:install-perarch: perfjvmtiinstalldir = $(perfpkgdir)/usr/lib

debian/rules.d/2-binary-arch.mk:662:install-perarch: perfpythoninstalldir = $(perfpkgdir)/usr/lib/python3/dist-packages

debian/rules.d/2-binary-arch.mk:663:install-perarch: bpftoolinstalldir = $(bpftoolpkgdir)/usr/sbin

debian/rules.d/2-binary-arch.mk:665:install-perarch: $(stampdir)/stamp-build-perarch

debian/rules.d/2-binary-arch.mk:723:.PHONY: binary-perarch

debian/rules.d/2-binary-arch.mk:724:binary-perarch: toolspkg = $(tools_pkg_name)

debian/rules.d/2-binary-arch.mk:725:binary-perarch: cloudpkg = $(cloud_pkg_name)

debian/rules.d/2-binary-arch.mk:726:binary-perarch: bpftoolpkg = $(bpftool_pkg_name)

debian/rules.d/2-binary-arch.mk:727:binary-perarch: perfpkg = $(perf_pkg_name)

debian/rules.d/2-binary-arch.mk:728:binary-perarch: install-perarch

debian/rules.d/2-binary-arch.mk:753:.PHONY: binary-debs

**ubuntu\@ip-172-31-32-229**:**\~/bpfseal/kernel/linux-aws-7.0-bpfseal-build**$ chmod a+x debian/rules

chmod a+x debian/scripts/\*



if [ -d debian/scripts/misc ]; then

    chmod a+x debian/scripts/misc/\*

fi

**ubuntu\@ip-172-31-32-229**:**\~/bpfseal/kernel/linux-aws-7.0-bpfseal-build**$ sudo apt-get build-dep -y --only-source linux-aws-7.0

Reading package lists... Done

Reading package lists... Done

Building dependency tree... Done

Reading state information... Done

The following NEW packages will be installed:

  asciidoc asciidoc-base asciidoc-common bindgen-0.65 ca-certificates-java clang-17 clang-19 default-jdk-headless default-jre-headless dkms docbook-xml docbook-xsl docutils-common java-common libaudit-dev libcap-ng-dev libclang-common-17-dev

  libclang-common-19-dev libclang-cpp17t64 libclang-cpp19 libclang1-17t64 libclang1-19 libdebuginfod-dev libexpat1-dev libjs-jquery libjs-sphinxdoc libjs-underscore liblcms2-2 libllvm17t64 libnewt-dev libnl-3-dev libnl-genl-3-dev libnuma-dev

  libpcsclite1 libpng-dev libpython3-dev libpython3.12-dev libslang2-dev libstd-rust-1.75 libstd-rust-1.91 libstd-rust-1.91-dev libstd-rust-dev libtraceevent-dev libtracefs-dev libunwind-dev libxml2-utils llvm-17-linker-tools llvm-19

  llvm-19-dev llvm-19-linker-tools llvm-19-runtime llvm-19-tools makedumpfile openjdk-21-jdk-headless openjdk-21-jre-headless python3-dev python3-docutils python3-roman python3.12-dev rust-1.91-src rustc rustc-1.91 rustfmt-1.91 sgml-data

  sharutils uuid-dev xmlto xsltproc

0 upgraded, 68 newly installed, 0 to remove and 13 not upgraded.

Need to get 588 MB of archives.

After this operation, 2523 MB of additional disk space will be used.

Get:1 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 dkms all 3.0.11-1ubuntu13 [51.5 kB]

Get:2 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 asciidoc-common all 10.2.0-2 [104 kB]

Get:3 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 docbook-xsl all 1.79.2+dfsg-7 [1070 kB]

Get:4 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libxml2-utils amd64 2.9.14+dfsg-1.3ubuntu3.10 [39.4 kB]

Get:5 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 xsltproc amd64 1.1.39-0exp1ubuntu0.24.04.3 [15.0 kB]

Get:6 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 asciidoc-base all 10.2.0-2 [83.6 kB]

Get:7 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 asciidoc all 10.2.0-2 [3248 B]

Get:8 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libllvm17t64 amd64 1:17.0.6-9ubuntu1 [26.2 MB]

Get:9 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 libclang-cpp17t64 amd64 1:17.0.6-9ubuntu1 [12.9 MB]

Get:10 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 libclang-common-17-dev amd64 1:17.0.6-9ubuntu1 [690 kB]

Get:11 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 llvm-17-linker-tools amd64 1:17.0.6-9ubuntu1 [1308 kB]

Get:12 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 libclang1-17t64 amd64 1:17.0.6-9ubuntu1 [7353 kB]

Get:13 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 clang-17 amd64 1:17.0.6-9ubuntu1 [78.6 kB]

Get:14 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libstd-rust-1.75 amd64 1.75.0+dfsg0ubuntu1-0ubuntu7.4 [20.2 MB]

Get:15 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libstd-rust-dev amd64 1.75.0+dfsg0ubuntu1-0ubuntu7.4 [40.8 MB]

Get:16 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 rustc amd64 1.75.0+dfsg0ubuntu1-0ubuntu7.4 [3372 kB]

Get:17 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 bindgen-0.65 amd64 0.65.1+dfsg0-0ubuntu1 [1920 kB]

Get:18 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 ca-certificates-java all 20240118 [11.6 kB]

Get:19 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 libclang-cpp19 amd64 1:19.1.1-1ubuntu1\~24.04.2 [14.3 MB]

Get:20 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 libclang-common-19-dev amd64 1:19.1.1-1ubuntu1\~24.04.2 [743 kB]

Get:21 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 llvm-19-linker-tools amd64 1:19.1.1-1ubuntu1\~24.04.2 [1314 kB]

Get:22 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 libclang1-19 amd64 1:19.1.1-1ubuntu1\~24.04.2 [8272 kB]

Get:23 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 clang-19 amd64 1:19.1.1-1ubuntu1\~24.04.2 [78.9 kB]

Get:24 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 java-common all 0.75+exp1 [6798 B]

Get:25 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 liblcms2-2 amd64 2.14-2ubuntu0.1 [161 kB]

Get:26 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libpcsclite1 amd64 2.0.3-1build1 [21.4 kB]

Get:27 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 openjdk-21-jre-headless amd64 21.0.12.1+1-1\~24.04.4 [46.5 MB]

Get:28 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 default-jre-headless amd64 2:1.21-75+exp1 [3094 B]

Get:29 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 openjdk-21-jdk-headless amd64 21.0.12.1+1-1\~24.04.4 [82.8 MB]

Get:30 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 default-jdk-headless amd64 2:1.21-75+exp1 [960 B]

Get:31 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 sgml-data all 2.0.11+nmu1 [171 kB]

Get:32 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 docbook-xml all 4.5-12 [74.6 kB]

Get:33 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 docutils-common all 0.20.1+dfsg-3 [132 kB]

Get:34 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libcap-ng-dev amd64 0.8.4-2build2 [29.9 kB]

Get:35 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libdebuginfod-dev amd64 0.190-1.1ubuntu0.1 [10.3 kB]

Get:36 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libexpat1-dev amd64 2.6.1-2ubuntu0.6 [147 kB]

Get:37 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libjs-jquery all 3.6.1+dfsg+\~3.5.14-1 [328 kB]

Get:38 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libjs-underscore all 1.13.4\~dfsg+\~1.11.4-3 [118 kB]

Get:39 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libjs-sphinxdoc all 7.2.6-6 [149 kB]

Get:40 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libpng-dev amd64 1.6.43-5ubuntu0.7 [265 kB]

Get:41 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libslang2-dev amd64 2.3.3-3build2 [560 kB]

Get:42 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libnewt-dev amd64 0.52.24-2ubuntu2 [71.1 kB]

Get:43 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libnl-3-dev amd64 3.7.0-0.3build1.1 [99.5 kB]

Get:44 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libnl-genl-3-dev amd64 3.7.0-0.3build1.1 [11.7 kB]

Get:45 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libpython3.12-dev amd64 3.12.3-1ubuntu0.17 [5684 kB]

Get:46 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libpython3-dev amd64 3.12.3-0ubuntu2.1 [10.3 kB]

Get:47 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 libstd-rust-1.91 amd64 1.91.1+dfsg\~24.04-0ubuntu0.24.04.3 [57.0 MB]

Get:48 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 libstd-rust-1.91-dev amd64 1.91.1+dfsg\~24.04-0ubuntu0.24.04.3 [46.4 MB]

Get:49 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libtraceevent-dev amd64 1:1.8.2-1ubuntu2.1 [64.8 kB]

Get:50 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 libtracefs-dev amd64 1.8.0-1ubuntu1 [76.1 kB]

Get:51 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libunwind-dev amd64 1.6.2-3build1.1 [1906 kB]

Get:52 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 llvm-19-runtime amd64 1:19.1.1-1ubuntu1\~24.04.2 [553 kB]

Get:53 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 llvm-19 amd64 1:19.1.1-1ubuntu1\~24.04.2 [17.8 MB]

Get:54 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 llvm-19-tools amd64 1:19.1.1-1ubuntu1\~24.04.2 [541 kB]

Get:55 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 llvm-19-dev amd64 1:19.1.1-1ubuntu1\~24.04.2 [47.5 MB]

Get:56 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 makedumpfile amd64 1:1.7.5-1ubuntu1 [179 kB]

Get:57 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 python3.12-dev amd64 3.12.3-1ubuntu0.17 [498 kB]

Get:58 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 python3-dev amd64 3.12.3-0ubuntu2.1 [26.7 kB]

Get:59 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 python3-roman all 3.3-3 [9632 B]

Get:60 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/main amd64 python3-docutils all 0.20.1+dfsg-3 [393 kB]

Get:61 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 rust-1.91-src all 1.91.1+dfsg\~24.04-0ubuntu0.24.04.3 [25.2 MB]

Get:62 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 rustc-1.91 amd64 1.91.1+dfsg\~24.04-0ubuntu0.24.04.3 [110 MB]

Get:63 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/universe amd64 rustfmt-1.91 amd64 1.91.1+dfsg\~24.04-0ubuntu0.24.04.3 [2146 kB]

Get:64 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 sharutils amd64 1:4.15.2-9 [259 kB]

Get:65 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble/universe amd64 xmlto amd64 0.0.28-2.1 [26.8 kB]

Get:66 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libaudit-dev amd64 1:3.1.2-2.1ubuntu0.1 [80.3 kB]

Get:67 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 libnuma-dev amd64 2.0.18-1ubuntu0.24.04.1 [37.0 kB]

Get:68 http\://us-east-1.ec2.archive.ubuntu.com/ubuntu noble-updates/main amd64 uuid-dev amd64 2.39.3-9ubuntu6.6 [33.5 kB]

Fetched 588 MB in 4s (139 MB/s)       

Extracting templates from packages: 100%

Selecting previously unselected package dkms.

(Reading database ... 95488 files and directories currently installed.)

Preparing to unpack .../00-dkms_3.0.11-1ubuntu13_all.deb ...

Unpacking dkms (3.0.11-1ubuntu13) ...

Selecting previously unselected package asciidoc-common.

Preparing to unpack .../01-asciidoc-common_10.2.0-2_all.deb ...

Unpacking asciidoc-common (10.2.0-2) ...

Selecting previously unselected package docbook-xsl.

Preparing to unpack .../02-docbook-xsl_1.79.2+dfsg-7_all.deb ...

Unpacking docbook-xsl (1.79.2+dfsg-7) ...

Selecting previously unselected package libxml2-utils.

Preparing to unpack .../03-libxml2-utils_2.9.14+dfsg-1.3ubuntu3.10_amd64.deb ...

Unpacking libxml2-utils (2.9.14+dfsg-1.3ubuntu3.10) ...

Selecting previously unselected package xsltproc.

Preparing to unpack .../04-xsltproc_1.1.39-0exp1ubuntu0.24.04.3_amd64.deb ...

Unpacking xsltproc (1.1.39-0exp1ubuntu0.24.04.3) ...

Selecting previously unselected package asciidoc-base.

Preparing to unpack .../05-asciidoc-base_10.2.0-2_all.deb ...

Unpacking asciidoc-base (10.2.0-2) ...

Selecting previously unselected package asciidoc.

Preparing to unpack .../06-asciidoc_10.2.0-2_all.deb ...

Unpacking asciidoc (10.2.0-2) ...

Selecting previously unselected package libllvm17t64:amd64.

Preparing to unpack .../07-libllvm17t64_1%3a17.0.6-9ubuntu1_amd64.deb ...

Unpacking libllvm17t64:amd64 (1:17.0.6-9ubuntu1) ...

Selecting previously unselected package libclang-cpp17t64.

Preparing to unpack .../08-libclang-cpp17t64_1%3a17.0.6-9ubuntu1_amd64.deb ...

Unpacking libclang-cpp17t64 (1:17.0.6-9ubuntu1) ...

Selecting previously unselected package libclang-common-17-dev:amd64.

Preparing to unpack .../09-libclang-common-17-dev_1%3a17.0.6-9ubuntu1_amd64.deb ...

Unpacking libclang-common-17-dev:amd64 (1:17.0.6-9ubuntu1) ...

Selecting previously unselected package llvm-17-linker-tools.

Preparing to unpack .../10-llvm-17-linker-tools_1%3a17.0.6-9ubuntu1_amd64.deb ...

Unpacking llvm-17-linker-tools (1:17.0.6-9ubuntu1) ...

Selecting previously unselected package libclang1-17t64.

Preparing to unpack .../11-libclang1-17t64_1%3a17.0.6-9ubuntu1_amd64.deb ...

Unpacking libclang1-17t64 (1:17.0.6-9ubuntu1) ...

Selecting previously unselected package clang-17.

Preparing to unpack .../12-clang-17_1%3a17.0.6-9ubuntu1_amd64.deb ...

Unpacking clang-17 (1:17.0.6-9ubuntu1) ...

Selecting previously unselected package libstd-rust-1.75:amd64.

Preparing to unpack .../13-libstd-rust-1.75_1.75.0+dfsg0ubuntu1-0ubuntu7.4_amd64.deb ...

Unpacking libstd-rust-1.75:amd64 (1.75.0+dfsg0ubuntu1-0ubuntu7.4) ...

Selecting previously unselected package libstd-rust-dev:amd64.

Preparing to unpack .../14-libstd-rust-dev_1.75.0+dfsg0ubuntu1-0ubuntu7.4_amd64.deb ...

Unpacking libstd-rust-dev:amd64 (1.75.0+dfsg0ubuntu1-0ubuntu7.4) ...

Selecting previously unselected package rustc.

Preparing to unpack .../15-rustc_1.75.0+dfsg0ubuntu1-0ubuntu7.4_amd64.deb ...

Unpacking rustc (1.75.0+dfsg0ubuntu1-0ubuntu7.4) ...

Selecting previously unselected package bindgen-0.65.

Preparing to unpack .../16-bindgen-0.65_0.65.1+dfsg0-0ubuntu1_amd64.deb ...

Unpacking bindgen-0.65 (0.65.1+dfsg0-0ubuntu1) ...

Selecting previously unselected package ca-certificates-java.

Preparing to unpack .../17-ca-certificates-java_20240118_all.deb ...

Unpacking ca-certificates-java (20240118) ...

Selecting previously unselected package libclang-cpp19.

Preparing to unpack .../18-libclang-cpp19_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking libclang-cpp19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package libclang-common-19-dev:amd64.

Preparing to unpack .../19-libclang-common-19-dev_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking libclang-common-19-dev:amd64 (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package llvm-19-linker-tools.

Preparing to unpack .../20-llvm-19-linker-tools_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking llvm-19-linker-tools (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package libclang1-19.

Preparing to unpack .../21-libclang1-19_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking libclang1-19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package clang-19.

Preparing to unpack .../22-clang-19_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking clang-19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package java-common.

Preparing to unpack .../23-java-common_0.75+exp1_all.deb ...

Unpacking java-common (0.75+exp1) ...

Selecting previously unselected package liblcms2-2:amd64.

Preparing to unpack .../24-liblcms2-2_2.14-2ubuntu0.1_amd64.deb ...

Unpacking liblcms2-2:amd64 (2.14-2ubuntu0.1) ...

Selecting previously unselected package libpcsclite1:amd64.

Preparing to unpack .../25-libpcsclite1_2.0.3-1build1_amd64.deb ...

Unpacking libpcsclite1:amd64 (2.0.3-1build1) ...

Selecting previously unselected package openjdk-21-jre-headless:amd64.

Preparing to unpack .../26-openjdk-21-jre-headless_21.0.12.1+1-1\~24.04.4_amd64.deb ...

Unpacking openjdk-21-jre-headless:amd64 (21.0.12.1+1-1\~24.04.4) ...

Selecting previously unselected package default-jre-headless.

Preparing to unpack .../27-default-jre-headless_2%3a1.21-75+exp1_amd64.deb ...

Unpacking default-jre-headless (2:1.21-75+exp1) ...

Selecting previously unselected package openjdk-21-jdk-headless:amd64.

Preparing to unpack .../28-openjdk-21-jdk-headless_21.0.12.1+1-1\~24.04.4_amd64.deb ...

Unpacking openjdk-21-jdk-headless:amd64 (21.0.12.1+1-1\~24.04.4) ...

Selecting previously unselected package default-jdk-headless.

Preparing to unpack .../29-default-jdk-headless_2%3a1.21-75+exp1_amd64.deb ...

Unpacking default-jdk-headless (2:1.21-75+exp1) ...

Selecting previously unselected package sgml-data.

Preparing to unpack .../30-sgml-data_2.0.11+nmu1_all.deb ...

Unpacking sgml-data (2.0.11+nmu1) ...

Selecting previously unselected package docbook-xml.

Preparing to unpack .../31-docbook-xml_4.5-12_all.deb ...

Unpacking docbook-xml (4.5-12) ...

Selecting previously unselected package docutils-common.

Preparing to unpack .../32-docutils-common_0.20.1+dfsg-3_all.deb ...

Unpacking docutils-common (0.20.1+dfsg-3) ...

Selecting previously unselected package libcap-ng-dev:amd64.

Preparing to unpack .../33-libcap-ng-dev_0.8.4-2build2_amd64.deb ...

Unpacking libcap-ng-dev:amd64 (0.8.4-2build2) ...

Selecting previously unselected package libdebuginfod-dev:amd64.

Preparing to unpack .../34-libdebuginfod-dev_0.190-1.1ubuntu0.1_amd64.deb ...

Unpacking libdebuginfod-dev:amd64 (0.190-1.1ubuntu0.1) ...

Selecting previously unselected package libexpat1-dev:amd64.

Preparing to unpack .../35-libexpat1-dev_2.6.1-2ubuntu0.6_amd64.deb ...

Unpacking libexpat1-dev:amd64 (2.6.1-2ubuntu0.6) ...

Selecting previously unselected package libjs-jquery.

Preparing to unpack .../36-libjs-jquery_3.6.1+dfsg+\~3.5.14-1_all.deb ...

Unpacking libjs-jquery (3.6.1+dfsg+\~3.5.14-1) ...

Selecting previously unselected package libjs-underscore.

Preparing to unpack .../37-libjs-underscore_1.13.4\~dfsg+\~1.11.4-3_all.deb ...

Unpacking libjs-underscore (1.13.4\~dfsg+\~1.11.4-3) ...

Selecting previously unselected package libjs-sphinxdoc.

Preparing to unpack .../38-libjs-sphinxdoc_7.2.6-6_all.deb ...

Unpacking libjs-sphinxdoc (7.2.6-6) ...

Selecting previously unselected package libpng-dev:amd64.

Preparing to unpack .../39-libpng-dev_1.6.43-5ubuntu0.7_amd64.deb ...

Unpacking libpng-dev:amd64 (1.6.43-5ubuntu0.7) ...

Selecting previously unselected package libslang2-dev:amd64.

Preparing to unpack .../40-libslang2-dev_2.3.3-3build2_amd64.deb ...

Unpacking libslang2-dev:amd64 (2.3.3-3build2) ...

Selecting previously unselected package libnewt-dev:amd64.

Preparing to unpack .../41-libnewt-dev_0.52.24-2ubuntu2_amd64.deb ...

Unpacking libnewt-dev:amd64 (0.52.24-2ubuntu2) ...

Selecting previously unselected package libnl-3-dev:amd64.

Preparing to unpack .../42-libnl-3-dev_3.7.0-0.3build1.1_amd64.deb ...

Unpacking libnl-3-dev:amd64 (3.7.0-0.3build1.1) ...

Selecting previously unselected package libnl-genl-3-dev:amd64.

Preparing to unpack .../43-libnl-genl-3-dev_3.7.0-0.3build1.1_amd64.deb ...

Unpacking libnl-genl-3-dev:amd64 (3.7.0-0.3build1.1) ...

Selecting previously unselected package libpython3.12-dev:amd64.

Preparing to unpack .../44-libpython3.12-dev_3.12.3-1ubuntu0.17_amd64.deb ...

Unpacking libpython3.12-dev:amd64 (3.12.3-1ubuntu0.17) ...

Selecting previously unselected package libpython3-dev:amd64.

Preparing to unpack .../45-libpython3-dev_3.12.3-0ubuntu2.1_amd64.deb ...

Unpacking libpython3-dev:amd64 (3.12.3-0ubuntu2.1) ...

Selecting previously unselected package libstd-rust-1.91:amd64.

Preparing to unpack .../46-libstd-rust-1.91_1.91.1+dfsg\~24.04-0ubuntu0.24.04.3_amd64.deb ...

Unpacking libstd-rust-1.91:amd64 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Selecting previously unselected package libstd-rust-1.91-dev:amd64.

Preparing to unpack .../47-libstd-rust-1.91-dev_1.91.1+dfsg\~24.04-0ubuntu0.24.04.3_amd64.deb ...

Unpacking libstd-rust-1.91-dev:amd64 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Selecting previously unselected package libtraceevent-dev:amd64.

Preparing to unpack .../48-libtraceevent-dev_1%3a1.8.2-1ubuntu2.1_amd64.deb ...

Unpacking libtraceevent-dev:amd64 (1:1.8.2-1ubuntu2.1) ...

Selecting previously unselected package libtracefs-dev:amd64.

Preparing to unpack .../49-libtracefs-dev_1.8.0-1ubuntu1_amd64.deb ...

Unpacking libtracefs-dev:amd64 (1.8.0-1ubuntu1) ...

Selecting previously unselected package libunwind-dev:amd64.

Preparing to unpack .../50-libunwind-dev_1.6.2-3build1.1_amd64.deb ...

Unpacking libunwind-dev:amd64 (1.6.2-3build1.1) ...

Selecting previously unselected package llvm-19-runtime.

Preparing to unpack .../51-llvm-19-runtime_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking llvm-19-runtime (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package llvm-19.

Preparing to unpack .../52-llvm-19_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking llvm-19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package llvm-19-tools.

Preparing to unpack .../53-llvm-19-tools_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking llvm-19-tools (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package llvm-19-dev.

Preparing to unpack .../54-llvm-19-dev_1%3a19.1.1-1ubuntu1\~24.04.2_amd64.deb ...

Unpacking llvm-19-dev (1:19.1.1-1ubuntu1\~24.04.2) ...

Selecting previously unselected package makedumpfile.

Preparing to unpack .../55-makedumpfile_1%3a1.7.5-1ubuntu1_amd64.deb ...

Unpacking makedumpfile (1:1.7.5-1ubuntu1) ...

Selecting previously unselected package python3.12-dev.

Preparing to unpack .../56-python3.12-dev_3.12.3-1ubuntu0.17_amd64.deb ...

Unpacking python3.12-dev (3.12.3-1ubuntu0.17) ...

Selecting previously unselected package python3-dev.

Preparing to unpack .../57-python3-dev_3.12.3-0ubuntu2.1_amd64.deb ...

Unpacking python3-dev (3.12.3-0ubuntu2.1) ...

Selecting previously unselected package python3-roman.

Preparing to unpack .../58-python3-roman_3.3-3_all.deb ...

Unpacking python3-roman (3.3-3) ...

Selecting previously unselected package python3-docutils.

Preparing to unpack .../59-python3-docutils_0.20.1+dfsg-3_all.deb ...

Unpacking python3-docutils (0.20.1+dfsg-3) ...

Selecting previously unselected package rust-1.91-src.

Preparing to unpack .../60-rust-1.91-src_1.91.1+dfsg\~24.04-0ubuntu0.24.04.3_all.deb ...

Unpacking rust-1.91-src (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Selecting previously unselected package rustc-1.91.

Preparing to unpack .../61-rustc-1.91_1.91.1+dfsg\~24.04-0ubuntu0.24.04.3_amd64.deb ...

Unpacking rustc-1.91 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Selecting previously unselected package rustfmt-1.91.

Preparing to unpack .../62-rustfmt-1.91_1.91.1+dfsg\~24.04-0ubuntu0.24.04.3_amd64.deb ...

Unpacking rustfmt-1.91 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Selecting previously unselected package sharutils.

Preparing to unpack .../63-sharutils_1%3a4.15.2-9_amd64.deb ...

Unpacking sharutils (1:4.15.2-9) ...

Selecting previously unselected package xmlto.

Preparing to unpack .../64-xmlto_0.0.28-2.1_amd64.deb ...

Unpacking xmlto (0.0.28-2.1) ...

Selecting previously unselected package libaudit-dev:amd64.

Preparing to unpack .../65-libaudit-dev_1%3a3.1.2-2.1ubuntu0.1_amd64.deb ...

Unpacking libaudit-dev:amd64 (1:3.1.2-2.1ubuntu0.1) ...

Selecting previously unselected package libnuma-dev:amd64.

Preparing to unpack .../66-libnuma-dev_2.0.18-1ubuntu0.24.04.1_amd64.deb ...

Unpacking libnuma-dev:amd64 (2.0.18-1ubuntu0.24.04.1) ...

Selecting previously unselected package uuid-dev:amd64.

Preparing to unpack .../67-uuid-dev_2.39.3-9ubuntu6.6_amd64.deb ...

Unpacking uuid-dev:amd64 (2.39.3-9ubuntu6.6) ...

Setting up liblcms2-2:amd64 (2.14-2ubuntu0.1) ...

Setting up libdebuginfod-dev:amd64 (0.190-1.1ubuntu0.1) ...

Setting up libclang1-19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up libunwind-dev:amd64 (1.6.2-3build1.1) ...

Setting up java-common (0.75+exp1) ...

Setting up libclang-common-19-dev:amd64 (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up libpng-dev:amd64 (1.6.43-5ubuntu0.7) ...

Setting up xsltproc (1.1.39-0exp1ubuntu0.24.04.3) ...

Setting up dkms (3.0.11-1ubuntu13) ...

Setting up libnuma-dev:amd64 (2.0.18-1ubuntu0.24.04.1) ...

Setting up asciidoc-common (10.2.0-2) ...

Setting up python3-roman (3.3-3) ...

Setting up libllvm17t64:amd64 (1:17.0.6-9ubuntu1) ...

Setting up libexpat1-dev:amd64 (2.6.1-2ubuntu0.6) ...

Setting up libclang1-17t64 (1:17.0.6-9ubuntu1) ...

Setting up uuid-dev:amd64 (2.39.3-9ubuntu6.6) ...

Setting up docbook-xsl (1.79.2+dfsg-7) ...

Setting up libpcsclite1:amd64 (2.0.3-1build1) ...

Setting up libnl-3-dev:amd64 (3.7.0-0.3build1.1) ...

Setting up libstd-rust-1.91:amd64 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Setting up libclang-common-17-dev:amd64 (1:17.0.6-9ubuntu1) ...

Setting up libcap-ng-dev:amd64 (0.8.4-2build2) ...

Setting up docutils-common (0.20.1+dfsg-3) ...

Setting up libtracefs-dev:amd64 (1.8.0-1ubuntu1) ...

Setting up sgml-data (2.0.11+nmu1) ...

Setting up llvm-19-linker-tools (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up rust-1.91-src (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Setting up libjs-jquery (3.6.1+dfsg+\~3.5.14-1) ...

Setting up ca-certificates-java (20240118) ...

No JRE found. Skipping Java certificates setup.

Setting up sharutils (1:4.15.2-9) ...

Setting up makedumpfile (1:1.7.5-1ubuntu1) ...

Setting up llvm-19-runtime (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up libxml2-utils (2.9.14+dfsg-1.3ubuntu3.10) ...

Setting up llvm-19-tools (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up libjs-underscore (1.13.4\~dfsg+\~1.11.4-3) ...

Setting up libclang-cpp19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up libtraceevent-dev:amd64 (1:1.8.2-1ubuntu2.1) ...

Setting up libslang2-dev:amd64 (2.3.3-3build2) ...

Setting up rustfmt-1.91 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Setting up libstd-rust-1.91-dev:amd64 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Setting up llvm-17-linker-tools (1:17.0.6-9ubuntu1) ...

Setting up openjdk-21-jre-headless:amd64 (21.0.12.1+1-1\~24.04.4) ...

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/java to provide /usr/bin/java (java) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jpackage to provide /usr/bin/jpackage (jpackage) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/keytool to provide /usr/bin/keytool (keytool) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/rmiregistry to provide /usr/bin/rmiregistry (rmiregistry) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/lib/jexec to provide /usr/bin/jexec (jexec) in auto mode

Setting up libaudit-dev:amd64 (1:3.1.2-2.1ubuntu0.1) ...

Setting up libstd-rust-1.75:amd64 (1.75.0+dfsg0ubuntu1-0ubuntu7.4) ...

Setting up libpython3.12-dev:amd64 (3.12.3-1ubuntu0.17) ...

Setting up clang-19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up libnl-genl-3-dev:amd64 (3.7.0-0.3build1.1) ...

Setting up libclang-cpp17t64 (1:17.0.6-9ubuntu1) ...

Setting up libstd-rust-dev:amd64 (1.75.0+dfsg0ubuntu1-0ubuntu7.4) ...

Setting up python3.12-dev (3.12.3-1ubuntu0.17) ...

Setting up libnewt-dev:amd64 (0.52.24-2ubuntu2) ...

Setting up libjs-sphinxdoc (7.2.6-6) ...

Setting up rustc (1.75.0+dfsg0ubuntu1-0ubuntu7.4) ...

Setting up llvm-19 (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up rustc-1.91 (1.91.1+dfsg\~24.04-0ubuntu0.24.04.3) ...

Setting up libpython3-dev:amd64 (3.12.3-0ubuntu2.1) ...

Setting up clang-17 (1:17.0.6-9ubuntu1) ...

Setting up python3-dev (3.12.3-0ubuntu2.1) ...

Setting up llvm-19-dev (1:19.1.1-1ubuntu1\~24.04.2) ...

Setting up bindgen-0.65 (0.65.1+dfsg0-0ubuntu1) ...

Processing triggers for install-info (7.1-3build2) ...

Processing triggers for libc-bin (2.39-0ubuntu8.9) ...

Processing triggers for systemd (255.4-1ubuntu8.18) ...

Processing triggers for man-db (2.12.0-4build2) ...

Processing triggers for sgml-base (1.31) ...

Setting up python3-docutils (0.20.1+dfsg-3) ...

Setting up docbook-xml (4.5-12) ...

Setting up asciidoc-base (10.2.0-2) ...

Setting up asciidoc (10.2.0-2) ...

Processing triggers for sgml-base (1.31) ...

Setting up xmlto (0.0.28-2.1) ...

Processing triggers for ca-certificates-java (20240118) ...

Adding debian:ACCVRAIZ1.pem

Adding debian:AC_RAIZ_FNMT-RCM.pem

Adding debian:AC_RAIZ_FNMT-RCM_SERVIDORES_SEGUROS.pem

Adding debian:ANF_Secure_Server_Root_CA.pem

Adding debian:Actalis_Authentication_Root_CA.pem

Adding debian:Amazon_Root_CA_1.pem

Adding debian:Amazon_Root_CA_2.pem

Adding debian:Amazon_Root_CA_3.pem

Adding debian:Amazon_Root_CA_4.pem

Adding debian:Atos_TrustedRoot_2011.pem

Adding debian:Atos_TrustedRoot_Root_CA_ECC_TLS_2021.pem

Adding debian:Atos_TrustedRoot_Root_CA_RSA_TLS_2021.pem

Adding debian:Autoridad_de_Certificacion_Firmaprofesional_CIF_A62634068.pem

Adding debian:BJCA_Global_Root_CA1.pem

Adding debian:BJCA_Global_Root_CA2.pem

Adding debian:Buypass_Class_2_Root_CA.pem

Adding debian:Buypass_Class_3_Root_CA.pem

Adding debian:CA_Disig_Root_R2.pem

Adding debian:CFCA_EV_ROOT.pem

Adding debian:COMODO_ECC_Certification_Authority.pem

Adding debian:COMODO_RSA_Certification_Authority.pem

Adding debian:Certainly_Root_E1.pem

Adding debian:Certainly_Root_R1.pem

Adding debian:Certigna_Root_CA.pem

Adding debian:Certum_EC-384_CA.pem

Adding debian:Certum_Trusted_Network_CA.pem

Adding debian:Certum_Trusted_Network_CA_2.pem

Adding debian:Certum_Trusted_Root_CA.pem

Adding debian:D-TRUST_BR_Root_CA_1_2020.pem

Adding debian:D-TRUST_BR_Root_CA_2_2023.pem

Adding debian:D-TRUST_EV_Root_CA_1_2020.pem

Adding debian:D-TRUST_EV_Root_CA_2_2023.pem

Adding debian:D-TRUST_Root_Class_3_CA_2_2009.pem

Adding debian:D-TRUST_Root_Class_3_CA_2_EV_2009.pem

Adding debian:DigiCert_Assured_ID_Root_G2.pem

Adding debian:DigiCert_Assured_ID_Root_G3.pem

Adding debian:DigiCert_Global_Root_G2.pem

Adding debian:DigiCert_Global_Root_G3.pem

Adding debian:DigiCert_TLS_ECC_P384_Root_G5.pem

Adding debian:DigiCert_TLS_RSA4096_Root_G5.pem

Adding debian:DigiCert_Trusted_Root_G4.pem

Adding debian:Entrust_Root_Certification_Authority.pem

Adding debian:GDCA_TrustAUTH_R5_ROOT.pem

Adding debian:GTS_Root_R1.pem

Adding debian:GTS_Root_R3.pem

Adding debian:GTS_Root_R4.pem

Adding debian:GlobalSign_ECC_Root_CA\_-\_R4.pem

Adding debian:GlobalSign_ECC_Root_CA\_-\_R5.pem

Adding debian:GlobalSign_Root_CA\_-\_R3.pem

Adding debian:GlobalSign_Root_CA\_-\_R6.pem

Adding debian:GlobalSign_Root_E46.pem

Adding debian:GlobalSign_Root_R46.pem

Adding debian:Go_Daddy_Root_Certificate_Authority\_-\_G2.pem

Adding debian:HARICA_TLS_ECC_Root_CA_2021.pem

Adding debian:HARICA_TLS_RSA_Root_CA_2021.pem

Adding debian:Hellenic_Academic_and_Research_Institutions_ECC_RootCA_2015.pem

Adding debian:Hellenic_Academic_and_Research_Institutions_RootCA_2015.pem

Adding debian:HiPKI_Root_CA\_-\_G1.pem

Adding debian:Hongkong_Post_Root_CA_3.pem

Adding debian:ISRG_Root_X1.pem

Adding debian:ISRG_Root_X2.pem

Adding debian:IdenTrust_Commercial_Root_CA_1.pem

Adding debian:IdenTrust_Public_Sector_Root_CA_1.pem

Adding debian:Izenpe.com.pem

Adding debian:Microsec_e-Szigno_Root_CA_2009.pem

Adding debian:Microsoft_ECC_Root_Certificate_Authority_2017.pem

Adding debian:Microsoft_RSA_Root_Certificate_Authority_2017.pem

Adding debian:NAVER_Global_Root_Certification_Authority.pem

Adding debian:NetLock_Arany\_=Class_Gold=\_Főtanúsítvány.pem

Adding debian:OISTE_Server_Root_ECC_G1.pem

Adding debian:OISTE_Server_Root_RSA_G1.pem

Adding debian:OISTE_WISeKey_Global_Root_GB_CA.pem

Adding debian:OISTE_WISeKey_Global_Root_GC_CA.pem

Adding debian:QuoVadis_Root_CA_1_G3.pem

Adding debian:QuoVadis_Root_CA_2_G3.pem

Adding debian:QuoVadis_Root_CA_3_G3.pem

Adding debian:SSL.com_EV_Root_Certification_Authority_ECC.pem

Adding debian:SSL.com_EV_Root_Certification_Authority_RSA_R2.pem

Adding debian:SSL.com_Root_Certification_Authority_ECC.pem

Adding debian:SSL.com_Root_Certification_Authority_RSA.pem

Adding debian:SSL.com_TLS_ECC_Root_CA_2022.pem

Adding debian:SSL.com_TLS_RSA_Root_CA_2022.pem

Adding debian:SZAFIR_ROOT_CA2.pem

Adding debian:Sectigo_Public_Server_Authentication_Root_E46.pem

Adding debian:Sectigo_Public_Server_Authentication_Root_R46.pem

Adding debian:SecureSign_Root_CA12.pem

Adding debian:SecureSign_Root_CA14.pem

Adding debian:SecureSign_Root_CA15.pem

Adding debian:Security_Communication_ECC_RootCA1.pem

Adding debian:Security_Communication_RootCA2.pem

Adding debian:Starfield_Root_Certificate_Authority\_-\_G2.pem

Adding debian:Starfield_Services_Root_Certificate_Authority\_-\_G2.pem

Adding debian:SwissSign_RSA_TLS_Root_CA_2022\_-\_1.pem

Adding debian:T-TeleSec_GlobalRoot_Class_2.pem

Adding debian:T-TeleSec_GlobalRoot_Class_3.pem

Adding debian:TUBITAK_Kamu_SM_SSL_Kok_Sertifikasi\_-\_Surum_1.pem

Adding debian:TWCA_CYBER_Root_CA.pem

Adding debian:TWCA_Global_Root_CA.pem

Adding debian:TWCA_Root_Certification_Authority.pem

Adding debian:Telekom_Security_TLS_ECC_Root_2020.pem

Adding debian:Telekom_Security_TLS_RSA_Root_2023.pem

Adding debian:Telia_Root_CA_v2.pem

Adding debian:TrustAsia_Global_Root_CA_G3.pem

Adding debian:TrustAsia_Global_Root_CA_G4.pem

Adding debian:TrustAsia_TLS_ECC_Root_CA.pem

Adding debian:TrustAsia_TLS_RSA_Root_CA.pem

Adding debian:TunTrust_Root_CA.pem

Adding debian:UCA_Extended_Validation_Root.pem

Adding debian:UCA_Global_G2_Root.pem

Adding debian:USERTrust_ECC_Certification_Authority.pem

Adding debian:USERTrust_RSA_Certification_Authority.pem

Adding debian:certSIGN_Root_CA_G2.pem

Adding debian:e-Szigno_Root_CA_2017.pem

Adding debian:e-Szigno_TLS_Root_CA_2023.pem

Adding debian:ePKI_Root_Certification_Authority.pem

Adding debian:emSign_ECC_Root_CA\_-\_C3.pem

Adding debian:emSign_ECC_Root_CA\_-\_G3.pem

Adding debian:emSign_Root_CA\_-\_C1.pem

Adding debian:emSign_Root_CA\_-\_G1.pem

Adding debian:vTrus_ECC_Root_CA.pem

Adding debian:vTrus_Root_CA.pem

done.

Setting up openjdk-21-jdk-headless:amd64 (21.0.12.1+1-1\~24.04.4) ...

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jar to provide /usr/bin/jar (jar) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jarsigner to provide /usr/bin/jarsigner (jarsigner) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/javac to provide /usr/bin/javac (javac) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/javadoc to provide /usr/bin/javadoc (javadoc) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/javap to provide /usr/bin/javap (javap) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jcmd to provide /usr/bin/jcmd (jcmd) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jdb to provide /usr/bin/jdb (jdb) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jdeprscan to provide /usr/bin/jdeprscan (jdeprscan) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jdeps to provide /usr/bin/jdeps (jdeps) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jfr to provide /usr/bin/jfr (jfr) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jimage to provide /usr/bin/jimage (jimage) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jinfo to provide /usr/bin/jinfo (jinfo) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jlink to provide /usr/bin/jlink (jlink) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jmap to provide /usr/bin/jmap (jmap) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jmod to provide /usr/bin/jmod (jmod) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jps to provide /usr/bin/jps (jps) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jrunscript to provide /usr/bin/jrunscript (jrunscript) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jshell to provide /usr/bin/jshell (jshell) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jstack to provide /usr/bin/jstack (jstack) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jstat to provide /usr/bin/jstat (jstat) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jstatd to provide /usr/bin/jstatd (jstatd) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jwebserver to provide /usr/bin/jwebserver (jwebserver) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/serialver to provide /usr/bin/serialver (serialver) in auto mode

update-alternatives: using /usr/lib/jvm/java-21-openjdk-amd64/bin/jhsdb to provide /usr/bin/jhsdb (jhsdb) in auto mode

Setting up default-jre-headless (2:1.21-75+exp1) ...

Setting up default-jdk-headless (2:1.21-75+exp1) ...

Scanning processes...                                                                                                                                                                                                                               

Scanning linux images...                                                                                                                                                                                                                            



Running kernel seems to be up-to-date.



No services need to be restarted.



No containers need to be restarted.



No user sessions are running outdated binaries.



No VM guests are running outdated hypervisor (qemu) binaries on this host.

**ubuntu\@ip-172-31-32-229**:**\~/bpfseal/kernel/linux-aws-7.0-bpfseal-build**$ cd \~/bpfseal/kernel/linux-aws-7.0-bpfseal-build



{

  date -u

  uname -a

  head -5 debian/changelog

  head -8 Makefile

  readlink -f debian

} > \~/bpfseal/results/prebuild-environment.txt

**ubuntu\@ip-172-31-32-229**:**\~/bpfseal/kernel/linux-aws-7.0-bpfseal-build**$ 
